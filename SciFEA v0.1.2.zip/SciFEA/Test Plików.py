import os
import json
import copy


# os.path.join(ścieżka_1, ścieżka_2) – platformowo niezależne łączenie segmentów ścieżki (automatycznie dobiera separatory / lub \).
# os.path.exists(sciezka) (oraz os.path.isdir(sciezka)) – sprawdzenie, czy dany zasób istnieje na dysku.
# os.makedirs(sciezka, exist_ok=True) – bezpieczne tworzenie pełnego drzewa katalogów 
# (parametr exist_ok=True zapobiega zgłoszeniu wyjątku FileExistsError, jeśli folder już istnieje).
# os.listdir(katalog) – zwraca listę samych nazw plików i podkatalogów znajdujących się w 
# podanej ścieżce (uwaga: zwraca same nazwy, np. ["rama_msh.json", "dane.txt"], a nie pełne ścieżki).
# os.path.isfile(pelna_sciezka) – pozwala upewnić się, że badany element to rzeczywiście plik, a nie kolejny podfolder o pasującej nazwie.
# nazwa.endswith(sufiks) – metoda tekstowa weryfikująca, czy nazwa pliku kończy się wskazanym rozszerzeniem (np. "_msh.json").
# os.remove("plik.txt")      # usuwa plik
# os.unlink("plik.txt")    # to samo co os.remove
# os.rename("stary.txt", "nowy.txt")                    # zmiana nazwy w tym samym katalogu
# os.rename("dane.txt", "projekty/dane.txt")            # przeniesienie do innego katalogu
# os.rename(r"C:\a\dane.txt", r"D:\b\dane.txt")         # pełne ścieżki
# os.replace(a, b)- nadpisuje

# # 1. Wczytaj obecny stan pliku
# with open("dane.json", "r", encoding="utf-8") as f:
 # data = json.load(f)

# 2. Podmień tylko wybrany klucz
# data["node_loads"] = zmieniony_slownik

# 3. Zapisz zaktualizowaną całość
# with open("dane.json", "w", encoding="utf-8") as f:
    # json.dump(data, f, indent=4, ensure_ascii=False)#



sciezka = "/home/user/projekty/raport.txt"

os.path.basename(sciezka)        # 'raport.txt'
os.path.splitext(sciezka)[0]     # '/home/user/projekty/raport'
os.path.splitext(sciezka)[1]     # '.txt'

# pobranie folderu operowania, gdzie jest plik kodu:
code_path = os.path.dirname(__file__)
# pobieranie ścieżki folderu testowego:
main_path = os.path.join(code_path, r"FILE_TEST")
if os.path.exists(main_path):
    print("FOLDER ISTNIEJE")

def make_working_directory(project_name = "No_name"):
    try:
        working_path = os.path.join(main_path, f"{project_name}_SciFEAprj")
        # Folder obciążeń
        loads_path = os.path.join(working_path, "Loads")
        os.makedirs(loads_path)
        # Folder wyników
        results_path = os.path.join(working_path, "Results")
        os.makedirs(results_path)
        return { 
            "working_path" : working_path,
            "loads_path": loads_path,
            "results_path": results_path
        }
    except Exception as e:
        print(f"An error occured:\n{e}")
        return None

# Tworzenie folderu:
def create_working_directory():
    print("Create new working directory? (y/n)")
    choice = input("- ")
    if choice.lower().strip() == "y":
        creation_flag = None
        while creation_flag is None:
            project_name = input("Provide working directory name:\n- ")
            creation_flag = make_working_directory(project_name)
        working_paths = copy.deepcopy(creation_flag)
        del creation_flag
        print(f"Created working directory, path:\n {working_paths["working_path"]}")
        return
    else:
        print("Canceled directory creation")
        return

create_working_directory()