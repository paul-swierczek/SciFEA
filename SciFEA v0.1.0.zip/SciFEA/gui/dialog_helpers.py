import sys
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, 
    QPushButton, QLineEdit, QVBoxLayout, QHBoxLayout, 
    QListWidget, QGridLayout, QFormLayout, QMessageBox,
    QSizePolicy, QButtonGroup, QCheckBox, QRadioButton,
    QComboBox, QFileDialog, QDialog, QDialogButtonBox,
    QStackedWidget, QStackedLayout, QStyle, QLayout
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavigationToolbar
from PySide6.QtGui import (QPainter, QColor, QPen, QIcon, QBrush, QPixmap, QFont, QKeySequence)
from PySide6.QtCore import (Qt, QSize)
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
import numpy as np
import math
import sympy as sp

# ========================================
# Klasa dialogu zwracająca listę
# ========================================
class ListReportLog(QDialog):
    def __init__(self, parent = None, canvas = None, title = "No title", label_text = "Report:",  display_list = "No list", minimum_width = 400, minimum_height = 400):
        super().__init__(parent)
        self.canvas = canvas
        # Ustawienia interakcji:
        self.setModal(False)
        self.setWindowTitle(title)
        self.setMinimumWidth(minimum_width)
        self.setMinimumHeight(minimum_height)
        # Layouty:
        self.main_layout = QVBoxLayout(self) # Główny layout, po to aby przyciski dolne były zawsze w tym samym miejscu
        # Dodawanie Listy:
        label = QLabel(f"{label_text}")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.main_layout.addWidget(label)
        Log_list = QListWidget()
        Log_list.addItems(display_list)
        self.main_layout.addWidget(Log_list)

        # Dolna sekcja:
        close_btn = QPushButton("close")
        self.main_layout.addWidget(close_btn)
        close_btn.clicked.connect(self.close_dialog)

    def close_dialog(self):
        self.accept()


# ========================================
# Klasa dialogu pomocniczego canvasa:
# ========================================
class AuxilaryCanvas(FigureCanvas):
    def __init__(self, parent = None, width = 3, height = 3, dpi = 100):
        self.fig = Figure(figsize = (width, height), dpi = dpi)
        super().__init__(self.fig)          
        self.setParent(parent)              
        self.axes = self.fig.add_subplot(1, 1, 1)
        self.axes.set_aspect("equal")
        self.axes.clear()


# ========================================
# Klasa dialogu pomocniczego z przyciskami:
# ========================================
class ButtonsDialog(QDialog):
    def __init__(self, parent = None, canvas = None, title = "No title", information_text = "Report:",  
                 buttons_dict = {"btn_1": "return_val_1", "btn_2": "return_val_2"}, visuals = {"btn_2": "red;white"},
                 font_size: int = 10, minimum_width = 200, minimum_height = 200):
            super().__init__(parent)
            self.canvas = canvas
            # Ustawienia interakcji:
            self.setModal(False)
            self.setWindowTitle(title)
            self.setMinimumWidth(minimum_width)
            self.setMinimumHeight(minimum_height)
            # Layouty:
            self.main_layout = QVBoxLayout(self) # Główny layout, po to aby przyciski dolne były zawsze w tym samym miejscu
            # Dodawanie Listy:
            label = QLabel(f"{information_text}")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label_font = label.font()
            label_font.setPointSize(font_size)
            label.setFont(label_font)
            self.main_layout.addWidget(label)
            self.return_val = None
    
            # Dolna sekcja:
            self.main_layout.addStretch()
            bottom_lt = QHBoxLayout()
            self.main_layout.addLayout(bottom_lt)
            self.btns_dict = {}
            for btn_name, return_val in buttons_dict.items():
                self.btns_dict[btn_name] = {"widget": QPushButton(f"{btn_name}"),
                                            "return_val": return_val}
                try:
                    if btn_name in visuals:
                         colors = visuals[btn_name]
                         color_1 = colors.split(";")[0]
                         color_2 = colors.split(";")[1]
                         self.btns_dict[btn_name]["widget"].setStyleSheet(f"background-color: {color_1}; color: {color_2}")
                except Exception as e:
                    print(f"{type(e).__name__}: {e}")

                bottom_lt.addWidget(self.btns_dict[btn_name]["widget"])
                self.btns_dict[btn_name]["widget"].clicked.connect(lambda checked = False, val = return_val: self.close_dialog(val)) 
                # Trzeba pierwszy argument przypisać, bo przycisk zawsze pierwszą wartość przypisuje false

    def close_dialog(self, return_val):
         self.return_val = return_val
         self.accept()
