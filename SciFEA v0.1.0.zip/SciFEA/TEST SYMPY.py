import sys
import numpy as np
import math
import sympy as sp
import os


sympy_LOCAL = {"I": sp.Symbol("I"), "E": sp.Symbol("E"), "S": sp.Symbol("S")}
# S_y(z) = \frac{w}{2} \left[ \left(\frac{h}{2}\right)^2 - z^2 \right]
#słownik przekroju:
symbol_substitutes = {
    "length" : {"cm": 0.01}
}
u_channel = {
            "name": "section name not assigned",
            "shape_type": "u_channel",
            "shape_parameters": {
                "width": "10*cm",
                "height": "12*cm",
                "flange_thickness": "1.5*cm",
                "web_thickness": "2*cm"
            },
            "properties": {
                "area": 0.0048000000000000004,
                "inertia_y": 9.539999999999998e-06,
                "zuravsky_static_y": 9.900000000000001e-05,
                "max_z": 0.06
            },
        }

w_sp = sp.sympify(u_channel["shape_parameters"]["width"], locals = sympy_LOCAL)
h_sp = sp.sympify(u_channel["shape_parameters"]["height"], locals = sympy_LOCAL)
f_t_sp = sp.sympify(u_channel["shape_parameters"]["flange_thickness"], locals = sympy_LOCAL)
w_t_sp = sp.sympify(u_channel["shape_parameters"]["web_thickness"], locals = sympy_LOCAL)
h_val = h_sp.subs(symbol_substitutes["length"])
w_val = w_sp.subs(symbol_substitutes["length"])
f_t_val = f_t_sp.subs(symbol_substitutes["length"])
w_t_val = w_t_sp.subs(symbol_substitutes["length"])
# definiuję zmienne dla sympy:
w_t, h, w, f_t = sp.symbols("w_t, h, w, f_t", real = True, positive = True)
# definiuję zmienną:
z = sp.Symbol("z", real = True)
# wyrażenie:
S_y = w/2*((h/2)**2-z**2)
S_y = sp.simplify(S_y)

# całka nieoznaczona
integral_Sy = sp.integrate(S_y, z)
# pochodna po z
diff_intSy = sp.diff(integral_Sy, z)

print(sp.latex(integral_Sy))
print(sp.latex(diff_intSy)) 

difference = sp.simplify(S_y - diff_intSy)
print(f"difference: {sp.latex(difference)}")

# całka oznaczona, wyznaczenie funkcji:
z_s = sp.Symbol("z_s", positive = True)
S_y_up = sp.simplify(sp.integrate(w*z_s, (z_s, z, h/2)))
S_y_flangeConst = sp.integrate(z_s*w, (z_s, h/2-f_t, h/2))
S_y_down = sp.simplify(sp.integrate(z_s*w_t, (z_s, z, h/2-f_t)) + S_y_flangeConst)
print(f"całka od górnej części: {sp.latex(S_y_up)}")
print(f"całka od dolnej części: {sp.latex(S_y_down)}")

# funkcja, która przyjmuje różne wartości w zależności od warunków.
t_func = sp.Piecewise((w_t, z_s < h/2-f_t), 
                      (w, z_s >= h/2-f_t))
t_func_z = sp.Piecewise((w_t, z < h/2-f_t), 
                      (w, z >= h/2-f_t))

# funkcja momentu statycznego zauważ zapis (z>a) & (z<=b) 
S_y_func = sp.Piecewise((S_y_down, (z >= 0) & (z < h/2-f_t)),
                        (S_y_up, (z >= h/2-f_t) & (z <= h/2)))


print(f"funkcja szerokości: {sp.latex(t_func)}")
print(f"funkcja momentu statycznego: {sp.latex(S_y_func)}")

# tworzenie ułamka zwykłego:
example_1 = sp.Rational(1,10)
example_2 = sp.Rational(0.1)
example_3 = sp.Rational("0.1")
print(f"example 1:")
sp.pprint(example_1)
print(f"example 2:")
sp.pprint(example_2)
print(f"example 3:")
sp.pprint(example_3)

# tworzenie słownika substytutów z dokładniejszymi wartościami:
exact_subs = {}
for symbol, val in symbol_substitutes["length"].items():
    exact_subs[symbol] = sp.sympify(val, locals = sympy_LOCAL, rational = True)

def precise_subs(val, subs_dict):
    val_str = str(val) if isinstance(val, (int, float)) else val
    exact_expr = sp.sympify(val_str, locals = sympy_LOCAL, rational = True)
    # Wykonujemy podstawienie jednostek/symboli
    substituted = exact_expr.subs(subs_dict)
    # wymuszenie jebanego ułamka
    return sp.nsimplify(substituted)

# aby podstawił odpowiednio wartości musi być nie string "w" tylko znany już symbol w
section_subs = {
    w: precise_subs(u_channel["shape_parameters"]["width"], exact_subs),
    h: precise_subs(u_channel["shape_parameters"]["height"], exact_subs),
    f_t: precise_subs(u_channel["shape_parameters"]["flange_thickness"], exact_subs),
    w_t: precise_subs(u_channel["shape_parameters"]["web_thickness"], exact_subs)
}
print(exact_subs)
print(section_subs)

S_y_exact = S_y_func.subs(section_subs)
t_func_exact = t_func_z.subs(section_subs)
print(f"Funkcja zapisana numerycznie:\n{sp.latex(S_y_exact)}")

S_y_random = sp.N(S_y_exact.subs(z, sp.Rational(1,50)), 30)

print(f"Dokladne S_y:\n {S_y_exact.subs(z, sp.Rational(1,50))}")
print(f"Do 30 miejsca:\n {S_y_random}")

# zamiana do zajebiście szybkiego cwela z numpy sp.lambdify(arg, wyrażenie, modules), modules: Biblioteka, do której ma tłumaczyć (np. 'numpy').
# Funkcja Piecewise z SymPy tłumaczy się na numpy.select. 
# W NumPy warunki logiczne (np. z >= 0) muszą być zapisane za pomocą operatorów bitowych 
# (& zamiast and, | zamiast or) i nawiasów. lambdify zazwyczaj robi to automatycznie i poprawnie, 
# ale musisz pamiętać, że wejściem do takiej funkcji musi być tablica NumPy (np. np.array lub np.linspace), 
# a nie pojedyncza liczba (chyba że użyjesz numpy w trybie skalarowym).
S_y_fast = sp.lambdify(z, S_y_exact, modules = 'numpy')
# tworzenie punktów:
z_list = np.linspace(0, 0.06, 5)
S_y_vals = S_y_fast(z_list)
print(S_y_vals)

# Sprawdzam całkowanie Momentu statycznego:
print("STARTUJE")
static_y = sp.integrate(S_y_exact, (z, 0, section_subs[h]/2))
static_y_num = sp.N(static_y, 30)
print(f"Wyznaczony moment:\n{static_y}\nfloat:{static_y_num}")

Beta_J_nonintegral = sp.sympify(f"{u_channel['properties']['inertia_y']}**2/{u_channel['properties']['area']}", rational = True)
Beta_J_nonintegral_num = sp.N(Beta_J_nonintegral,30)
print(f"Przed calka: {Beta_J_nonintegral_num}")
Beta_J_integral = 2 * sp.integrate(S_y_exact**2/t_func_exact, (z, 0,  section_subs[h]/2))
# Ważne w przypadku wzoru trzeba podzielić
Beta_J = sp.nsimplify(Beta_J_nonintegral/Beta_J_integral)
Beta_J_num = sp.N(Beta_J, 30)

print(f"Wyznaczony współczynnik efektywności:\n{Beta_J}\nfloat:{Beta_J_num}")
